import React from 'react';
import PropTypes from 'prop-types';

class ValidateProps extends React.Component{
    render(){
        return(
            <div>
                <table>
                    <tr>
                        <th>Type</th>
                        <th>Value</th>
                        <th>Valid</th>
                    </tr>
                    <tr>
                        <td>Array</td>
                        <td>{this.props.ArrayType}</td>
                        <td>{this.props.ArrayType?"true" :"False"}</td>
                    </tr>
                    <tr>
                        <td>Boolean</td>
                        <td>{this.props.BooleanType}</td>
                        <td>{this.props.BooleanType?"true" :"False"}</td>
                    </tr>
                    <tr>
                        <td>Number</td>
                        <td>{this.props.NumberType}</td>
                        <td>{this.props.NumberType?"true" :"False"}</td>
                    </tr>
                </table>
            </div>
        )
    }
}
ValidateProps.propTypes={
    ArrayType:PropTypes.array.isRequired,
    BooleanType:PropTypes.bool.isRequired,
    NumberType:PropTypes.number

}

ValidateProps.defaultProps={
    ArrayType:[23,45,676,88],
    BooleanType:"true",
    NumberType:23

}
export default  ValidateProps;
