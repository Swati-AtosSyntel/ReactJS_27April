import React from 'react';

class App3 extends React.Component{
    constructor(){
        super();
        this.state={msg:"Welcome to React"};
        this.updateState=this.updateState.bind(this);
    }
    updateState(){
        this.setState({msg:"React is JS library"});
    }
    render(){
        return(
            <div>
                <Child message={this.state.msg} updateStateProp={this.updateState}></Child>
            </div>
        )
    }
}
class Child extends React.Component{
    render(){
        return(
            <div>
                <button onClick={this.props.updateStateProp}>Update Parent Compoenent State</button>
                <h2>{this.props.message}</h2>
            </div>
        )
    }
}
export default App3;