import React from 'react';

class Person extends React.Component{
    constructor(){
        super();
    }
    render(){
        return(
            <div>
                Hi {this.props.personName},
                Eye Color: {this.props.eyeColor},
                Age:{this.props.age}
            </div>

        )
    }
    
}
Person.defaultProps={
    personName:"Aditya",
    eyeColor:"deepblue",
    age:"20"
}

export default Person;