import React from 'react';

function App2()
{
    const languages=[{"id":"1","language":"C"},
    {"id":23,"language":"C++"}];
    const updatedlist=languages.map((lang)=>           
       <div key={lang.id}><h1>{lang.id}</h1> <li>{lang.language}</li></div>);
return(
    <ul>
        {updatedlist}
    </ul>
        
)
}

export default App2;