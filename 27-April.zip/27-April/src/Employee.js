import React from 'react';

class Employee extends React.Component{
    constructor(){
        super();
        this.state={
            emps:[
                {"eid":"123",ename:"Swati"},
                {"eid":"124",ename:"Manisha"},
                {"eid":"125",ename:"Sneha"},
                {"eid":"126",ename:"Ankita"}
            ]
        }
    }
    render(){
        return(
            <table border="1">
                <thead>
                    <th>Employee ID</th>
                    <th>Employee Name</th>
                </thead>
                <tbody>
                    {this.state.emps.map((emp)=>
                    <TableRow employee={emp}></TableRow>)}
                    
                </tbody>

            </table>
        )
    }
}
class TableRow extends React.Component{
    render(){
        return(

            <tr>
                <td>{this.props.employee.eid}</td>
                <td>{this.props.employee.ename}</td>
            </tr>




        );
    }
}
export default Employee;