import { buildQueries } from '@testing-library/dom';
import React from 'react';
import App from './App';
class Welcome extends React.Component{
    render(){
        var i=10;
        var style1={
            color:'blue'

        }

        return(
            <div>
                <h2>Hi {this.props.name}</h2>
                <h2>React is Javascript Library</h2>
                <h3 style={style1}>{12+23}</h3>
                <h3>{i==10?'True':'False'}</h3>
                <App name="Anushka"/>
                <App name="Sneha"/>
            </div>
        )
    }
}

export default Welcome;