import React from 'react';

class App4 extends React.Component{
    render(){
        const nums=[23,45,6,67,88]

        const doubleList=nums.map((n)=><li>{n*2}</li>)
        return(
            <ul>
                {doubleList}
            </ul>
        )
    }
}
export default App4;