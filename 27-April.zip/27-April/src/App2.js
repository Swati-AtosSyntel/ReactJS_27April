import React,{Component} from 'react';

class App2 extends React.Component{
    constructor(){
        super();
        this.state={
            fname:'Mahesh',
            lname:'Rajput'
        }
        this.changeName=this.updateState.bind(this);
    }
    updateState(){
        this.setState({fname:'Sneha',lname:'Kumar'})
    }
    render(){
        return(
            <div>
                <FirstName firstname={this.state.fname}/>
                <LastName lastname={this.state.lname}/>
                <button onClick={this.changeName}>Update State</button>
            </div>
        )
    }
}
class FirstName extends React.Component{
    render(){
        return(
            <h2>{this.props.firstname}</h2>
        )
    }
}

class LastName extends React.Component{
    render(){
        return(
            <h2>{this.props.lastname}</h2>
        )
    }
}
export default App2;