import React from 'react';

class App3 extends React.Component{
    constructor(){
        super();
        this.state={arr:[]}
        this.updateArray=this.updateArray.bind(this);
    }
    updateArray(){
        var tempArr=this.state.arr;
        tempArr.push("A1");
        
        this.setState({arr:tempArr});
        alert(this.state.arr);

    }
    render(){
        return(
            <div>
                <button onClick={this.updateArray}>Change State</button>
                <h2>Updated Array :</h2>
                <h2>{this.state.arr}</h2>
            </div>
        )
    }
}
export default App3;