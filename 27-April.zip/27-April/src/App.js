import logo from './logo.svg';
import './App.css';

function App(props) {
  return (
    <div>
      <h1>Hello World!!!!</h1>
      <h2>Hi {props.name}{props.location}</h2>
      </div>
  );
}

export default App;
